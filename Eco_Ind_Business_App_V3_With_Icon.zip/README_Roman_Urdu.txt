Eco Ind Business App V3 - Installable PWA

IMPORTANT:
Ye PWA local HTML file se install nahi hoti. Isko kisi HTTPS website/hosting par upload karke Chrome Android mein open karna zaroori hai. Phir Chrome ka Install App / Add to Home Screen option aa sakta hai.

Files:
index.html
manifest.json
sw.js
icon.svg

App ka data browser ke local storage mein save hota hai.
